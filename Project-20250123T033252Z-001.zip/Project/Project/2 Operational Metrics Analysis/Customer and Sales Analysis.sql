

--The first step to calculating this metric is to have a flag that identifies the new and the returning customer. 
-- Customers with single and repeat purchases. We can calculate this column using SQL. 
--We create a grouping of the customers based on the customer�s transactions.

Use AdventureWorksDW2019
GO
with order_item as ( 
Select distinct
	f.CustomerKey,
	f.OrderDateKey, 
	f.ProductKey,
	p.EnglishProductName as ProductName
from dbo.FactInternetSales f
inner join DimProduct p on f.ProductKey = p.ProductKey
)

Select top 20
	a.ProductName, 
	b.ProductName , 
	count(*) frequency
from 

order_item a 
inner join
order_item b 

on a.CustomerKey = b.CustomerKey AND A.OrderDateKey = B.OrderDateKey
where a.ProductKey < b.ProductKey
Group by  a.ProductName, b.ProductName 
Order by count(*) DESC

--*********************************************

--On average, how many orders do we receive per day? Plus, what's our average sales per day?
with avg_sales_per_day as (

	select OrderDate, 
		   count(distinct SalesOrderNumber) as order_count,			sum(SalesAmount) as Sales
    from  [dbo].[FactInternetSales]
    group by OrderDate
)

select 
   avg(Sales) as avg_sales_day,
   avg(order_count) avg_order_count
from avg_sales_per_day




--Find out how many customers have repeat purchase. Define new vs returning customer. 
with customers as (

select CustomerKey,
ROW_NUMBER() Over (partition by CustomerKey Order by CustomerKey) as rownum
from [dbo].[FactInternetSales] f
)
, repeat_buyers as (
select distinct 	 CustomerKey FROM customers where  rownum > 1)
, first_purchase as (select distinct CustomerKey FROM customers where  rownum = 1)



select 
	case
		when r.CustomerKey IS NOT NULL
		then 'repeat'
		else 'new'
		end as repeat_new,
		count(*) as number_of_customer,
		(	select count(distinct customerkey)
			from customers
			) as total_customers,
			FORMAT(cast(count(*) as decimal(18,2))/cast((select count(distinct customerkey)
									from customers) as decimal(18,2)), 'P') as repeat_rate
from first_purchase f 
left join  repeat_buyers r on f.CustomerKey = r.CustomerKey
group by 
	case
		when r.CustomerKey IS NOT NULL
		then 'repeat'
		else 'new'
		end